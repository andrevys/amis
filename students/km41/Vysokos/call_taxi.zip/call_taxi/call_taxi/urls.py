from django.conf import settings
from django.conf.urls import include, url
from django.conf.urls.static import static
from django.contrib import admin

admin.autodiscover()


urlpatterns = [

    # Home pages
    url(r'^',
        include('main.urls', namespace='main'), name='main'),

    # # # Subscriber related URLs
    # url(r'^signup/$', core_views.signup, name='signup'),

    # # url(r'^login/$', core_views.login, {'template_name': 'registration/login.html'}, name='login'),


    # url(r'parking/', include('parking.urls', namespace='parking'), name='parking'),

    # url(r'^signup/',
    #     include('signup.urls', namespace='signup'), name='signup'),

    # # Votes pages
    # url(r'vote/', include('voting.urls', namespace='voting'), name='voting'),

    # Admin URL
    url(r'^admin/',
        admin.site.urls),

    # # Login/Logout URLs
    # url(r'^login/$',
    #     auth_views.login, {'template_name': 'login.html'}, name='login'
    #     ),
    # url(r'^logout/$',
    #     auth_views.logout, {'next_page': '/login/'}, name='logout'
    #     ),

] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
