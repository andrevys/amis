from django.conf.urls import url

from . import views
from django.contrib.auth import views as authorizate

urlpatterns = [

    url(r'^$', views.mainpage, name='main'),

    url(r'^signup/$', views.signup, name='signup'),

    url(r'^login/$', authorizate.login, {'template_name': 'login.html'}, name='login'),

    url(r'^logout/$', authorizate.logout, {'next_page': '/'}, name='logout'),

    url(r'^order/(?P<pk>\d+)/$', views.OrderView.as_view(), name='view_order'),

    url(r'^taxi/(?P<pk>\d+)/$', views.TaxiView.as_view(), name='view_taxi'),

    url(r'^login/$', authorizate.login, {'template_name': 'login.html'}, name='login'),

]
