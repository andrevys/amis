from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import Taxi
from .models import UserAdditionalInfo


class UserSignupForm(UserCreationForm):

    class Meta:
        model = UserAdditionalInfo
        fields = ('username', 'first_name', 'last_name', 'email', 'password1',
            'password2', 'role', 'phone')


    def save(self, commit=True):
        user = super(UserSignupForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.role = self.cleaned_data['role']
        user.phone = self.cleaned_data['phone']

        user.save()

        return user


class TaxiForm(forms.ModelForm):
    class Meta:
        model = Taxi
        exclude = ('owner', 'driving_from', 'driving_till')
