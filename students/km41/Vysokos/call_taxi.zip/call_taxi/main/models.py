from django.db import models
from django.contrib.auth.models import User

ROLE_CHOICE = (
    ('Driver', 'Driver'),
    ('Passenger', 'Passenger'),
)


from django.contrib.auth.models import AbstractUser
from django.conf import settings

class UserAdditionalInfo(AbstractUser):
    role = models.CharField(
        max_length=10,
        choices=ROLE_CHOICE,
        default='Driver',
    )
    phone = models.CharField(max_length=100, null=True, blank=True)


class Taxi(models.Model):
    owner = models.OneToOneField(settings.AUTH_USER_MODEL)
    number = models.CharField(max_length=20, unique=True)
    price_per_km = models.PositiveIntegerField()
    driving_from = models.DateTimeField(null=True, blank=True)
    driving_till = models.DateTimeField(null=True, blank=True)
    car = models.CharField(max_length=155, null=True, blank=True)

    def __str__(self):
        return self.owner.username


class Order(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL)
    taxi = models.ForeignKey(Taxi)
    kilometers = models.PositiveIntegerField()
    place_from = models.CharField(max_length=155, null=True)
    place_to = models.CharField(max_length=155, null=True)
    ordertime_from = models.DateTimeField(null=True, blank=True)
    ordertime_till = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return '{} on taxi of {}'.format(self.user.username, self.taxi.owner.username)
