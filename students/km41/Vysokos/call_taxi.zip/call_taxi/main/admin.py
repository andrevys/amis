from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import UserAdditionalInfo
from .models import Taxi, Order, UserAdditionalInfo


class UserAdmin(BaseUserAdmin):
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('User info', {'fields': ('username', 'first_name', 'last_name', 'email', 'phone', 'role', 'is_active', 'is_superuser', 'is_staff',)}),
    )    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'first_name', 'last_name', 'email', 'password1', 'password2', 'phone', 'role', 'is_active', 'is_superuser', 'is_staff')}
        ),
    )


admin.site.register(Taxi)
admin.site.register(Order)
admin.site.register(UserAdditionalInfo, UserAdmin)
