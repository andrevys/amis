from django.views import View
from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect
from django.utils import timezone
import datetime
# from django.contrib.auth.models import User

from django.contrib.auth import authenticate, login
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.utils.decorators import method_decorator
from django.db import connection
from django.db import transaction

from .forms import TaxiForm
from .models import Taxi, Order

def try_to_make_available(taxies):
    for taxi in taxies:
        if taxi.driving_from:
            if timezone.now() >= taxi.driving_from:
                taxi.driving_from = None
        if taxi.driving_till:
            if timezone.now() >= taxi.driving_till:
                taxi.driving_till = None
        taxi.save()

def get_orders(request):
    try:
        user_role = request.user.role
    except:
        return None
    if user_role == 'Driver':
        try:
            taxi = Taxi.objects.get(owner_id=request.user.id)
        except Exception:
            taxi = None
            orders = None
        if taxi:
            orders = Order.objects.filter(taxi_id=taxi.id)
    else:
        orders = Order.objects.filter(user_id=request.user.id)
    return orders

def mainpage(request):
    taxies = Taxi.objects.all()[:10]
    template_name = 'home.html'
    try_to_make_available(taxies)

    orders = get_orders(request)

    return render(request, template_name, {'taxies': taxies, 'orders': orders})

from .forms import UserSignupForm
from .models import UserAdditionalInfo


def signup(request, template='signup.html'):
    if request.method == 'GET':
        form = UserSignupForm(request.POST)

    if request.method == 'POST':
        form = UserSignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')

    return render(request, template, {'form':form})


@method_decorator(login_required, name='dispatch')
class OrderView(View):

    def get(self, request, pk, *args, **kwargs):
        try:
            order = Order.objects.raw('SELECT * FROM MAIN_ORDER WHERE ID = {}'.format(pk))[0]

        except Exception:
            return redirect('/')
        taxies = Taxi.objects.all()[:10]
        try_to_make_available(taxies)

        orders = get_orders(request)

        return render(request, 'orders/order-details.html', {'order': order, 'taxies': taxies, 
            'orders': orders})

    def post(self, request, pk, *args, **kwargs):
        km, hours, place_from, place_to = request.POST.getlist('taxi')
        taxi = Taxi.objects.get(pk=pk)
        now = datetime.datetime.now()
        driving_from = now + datetime.timedelta(minutes=15)
        driving_till = now + datetime.timedelta(minutes=15) + datetime.timedelta(hours=int(hours))
        
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            taxi.driving_from = driving_from
            taxi.driving_till = driving_till
            taxi.save()
     
            order = Order.objects.create(user=request.user, taxi=taxi, kilometers=km,
                place_from=place_from, place_to=place_to)

            # order.ordertime_from = driving_from  TRIGGER create_time_order
            order.ordertime_till = driving_till
            order.save()

        return HttpResponseRedirect(reverse('main:view_order', args=(order.id,)))

@method_decorator(login_required, name='dispatch')
class TaxiView(View):

    def get(self, request, pk, *args, **kwargs):
        try:
            taxi = Taxi.objects.get(pk=pk)
        except Exception:
            return redirect('/')

        form = TaxiForm()
        taxies = Taxi.objects.all()[:10]
        try_to_make_available(taxies)

        can_create_taxi = can_order = False

        user_id = request.user.id
        user_role = request.user.role
        user_has_taxi = Taxi.objects.filter(owner_id=user_id)

        if user_role=='Driver' and not user_has_taxi:
            can_create_taxi = True
        if user_role=='Passenger':
            can_order = True

        orders = get_orders(request)

        return render(request, 'taxis/taxi-details.html', {'taxi': taxi, 'form': form,
            'taxies': taxies, 'can_create_taxi': can_create_taxi, 'can_order': can_order,
            'orders': orders})

    def post(self, request, pk, *args, **kwargs):

        taxies = Taxi.objects.all()[:10]
        try_to_make_available(taxies)

        user = request.user
        form = TaxiForm(request.POST)

        if form.is_valid():
            owner = request.user
            number = form.cleaned_data['number']
            price_per_km = form.cleaned_data['price_per_km']
            car = form.cleaned_data['car']

            taxi = Taxi.objects.create(owner=owner, number=number, price_per_km=price_per_km)
            taxi.car = car
            taxi.save()

            return redirect(reverse('main:view_taxi', args=(taxi.id,)))

        user_id = request.user.id
        user_role = request.user.role
        user_has_taxi = Taxi.objects.filter(owner_id=user_id)


        if user_role=='Driver' and not user_has_taxi:
            can_create_taxi = True

        taxi = Taxi.objects.get(pk=pk)
        return render(request, 'taxis/taxi-details.html', 
            {'form':form,
            'taxies': taxies,
            'can_create_taxi': can_create_taxi,
            'taxi': taxi
            })
